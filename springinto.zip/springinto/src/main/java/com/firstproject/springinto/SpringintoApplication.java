package com.firstproject.springinto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringintoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringintoApplication.class, args);
	}

}
